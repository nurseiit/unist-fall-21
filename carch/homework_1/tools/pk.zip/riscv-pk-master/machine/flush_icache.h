// See LICENSE for license details.

#ifndef _RISCV_FLUSH_ICACHE_H
#define _RISCV_FLUSH_ICACHE_H

void __riscv_flush_icache(void);

#endif /* _RISCV_FLUSH_ICACHE_H */
