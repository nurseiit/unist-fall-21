require_extension(EXT_ZBB);
WRITE_RD(RS1 & ~RS2);
