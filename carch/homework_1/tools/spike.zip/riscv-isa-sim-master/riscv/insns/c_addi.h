require_extension('C');
WRITE_RD(sext_xlen(RVC_RS1 + insn.rvc_imm()));
