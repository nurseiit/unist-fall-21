require_extension(EXT_XBITMANIP);
WRITE_RD((RS1 & RS2) | (RS3 & ~RS2));
