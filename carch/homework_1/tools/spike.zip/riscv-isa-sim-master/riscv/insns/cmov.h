require_extension(EXT_XBITMANIP);
WRITE_RD(RS2 ? RS1 : RS3);
