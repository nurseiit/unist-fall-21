require_extension('D');
require_fp;
WRITE_RD(f64_classify(f64(FRS1)));
