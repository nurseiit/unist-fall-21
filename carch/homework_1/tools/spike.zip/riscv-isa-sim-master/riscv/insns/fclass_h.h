require_extension(EXT_ZFH);
require_fp;
WRITE_RD(f16_classify(f16(FRS1)));
