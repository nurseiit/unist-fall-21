require_extension(EXT_ZFH);
require_fp;
WRITE_FRD(f16_min(f16(FRS1), f16(FRS2)));
set_fp_exceptions;
