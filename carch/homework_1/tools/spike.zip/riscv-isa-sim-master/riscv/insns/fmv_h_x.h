require_extension(EXT_ZFH);
require_fp;
WRITE_FRD(f16(RS1));
