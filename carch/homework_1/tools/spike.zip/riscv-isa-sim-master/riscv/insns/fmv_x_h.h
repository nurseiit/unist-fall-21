require_extension(EXT_ZFH);
require_fp;
WRITE_RD(sext32((int16_t)(FRS1.v[0])));
