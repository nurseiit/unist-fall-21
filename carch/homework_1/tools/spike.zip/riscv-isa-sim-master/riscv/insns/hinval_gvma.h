require_extension(EXT_SVINVAL);
#include "hfence_gvma.h"
